<?php

return [
	'title' => 'Mahorat & Management - Контактлар',
	'header' => 'Контактлар',
	'sub-header' => '',
	'our-experts' => 'Контактлар Mahorat & Management',
	'address' => 'Манзил:',
	'address-1' => 'Шота Руставели кўчаси 53Б',
	'address-2' => 'Тошкент, Ўзбекистон, 100003',
	'phone' => 'Телефон:',
	'contact-us' => 'Биз билан боғланинг',
	'your-message' => 'Хабарингиз юборилди, раҳмат!',
	'full-name' => 'Исм шарифингиз',
	'email-address' => 'Электрон почта манзили',
	'subject' => 'Мавзу',
	'message' => 'Хабар',
	'send-message' => 'Хабарни юбориш',


];
