<?php

return [
	'title' => 'Mahorat & Management - Contacts',
	'header' => 'Contacts',
	'sub-header' => '',
	'our-experts' => 'Contact Mahorat & Management',
	'address' => 'Address:',
	'address-1' => 'Shota Rustavili Street 53B',
	'address-2' => 'Tashkent, Uzbekistan 100003',
	'phone' => 'Phone:',
	'contact-us' => 'Contact Us',
	'your-message' => 'Your message was sent, thank you!',
	'full-name' => 'Full Name',
	'email-address' => 'Email Address',
	'subject' => 'Subject',
	'message' => 'Message',
	'send-message' => 'Send Message',


];
