<?php

return [
	'title' => 'Mahorat & Management - Kontaktlar',
	'header' => 'Kontaktlar',
	'sub-header' => '',
	'our-experts' => 'Kontaktlar Mahorat & Management',
	'address' => 'Manzil:',
	'address-1' => 'Shota Rustaveli ko‘chasi 53B',
	'address-2' => 'Toshkent, O‘zbekiston, 100003',
	'phone' => 'Telefon:',
	'contact-us' => 'Biz bilan bog‘laning',
	'your-message' => 'Xabaringiz yuborildi, rahmat!',
	'full-name' => 'Ism sharifingiz',
	'email-address' => 'Elektron pochta manzili',
	'subject' => 'Mavzu',
	'message' => 'Xabar',
	'send-message' => 'Xabarni yuborish',

];
