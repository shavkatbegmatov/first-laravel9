<?php

return [
	'title' => 'Mahorat & Management - Контакты',
	'header' => 'Контакты',
	'sub-header' => '',
	'our-experts' => 'Контакты Mahorat & Management',
	'address' => 'Адрес:',
	'address-1' => 'Улица Шота Руставели 53Б',
	'address-2' => 'Ташкент, Узбекистан 100003',
	'phone' => 'Телефон:',
	'contact-us' => 'Связаться с нами',
	'your-message' => 'Ваше сообщение отправлено, спасибо!',
	'full-name' => 'ФИО',
	'email-address' => 'Адрес электронной почты',
	'subject' => 'Предмет',
	'message' => 'Сообщение',
	'send-message' => 'Отправить сообщение',


];
